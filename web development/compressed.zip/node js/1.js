var a=10
var b=20
sum=a+b
console.log(sum)