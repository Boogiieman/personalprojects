var read=require('readline-sync')

var value=read.question('Enter a number')

console.log(value)