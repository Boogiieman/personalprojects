let add1=(a,b) => a+b
console.log(add1(10,20))