function hello(){
    console.log('Hello')
    return 10
}
console.log(hello())