var r=require('readline-sync')
num1=r.question('Enter 2 numbers')
num2=r.question('')

if(num1>num2){
    console.log(num1+'is large')
}
else if (num1===num2){
    console.log('Same digits')
}
else{
    console.log(num2+'is large')
}