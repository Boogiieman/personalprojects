var name="Boogieman"
var n=10
var s=true
console.log(name.length)
console.log('Hi'+name);