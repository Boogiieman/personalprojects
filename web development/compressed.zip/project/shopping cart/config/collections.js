module.exports={

    PRODUCT_COLLECTION:'product'
    
}