const { resolve } = require('promise')
const Promise=require('promise')

function getName(){
    return new Promise((resolve,reject)=>{
setTimeout(()=>{
    resolve("Yo")
},3000)
    })
}

function getMobile(){
    return new Promise((resolve,reject)=>{
setTimeout(()=>{
    resolve("1234567891")
},2000)
    })
}

/*
Promise.all([getName(),getMobile()]).then((result)=>{
console.log(result)
})
*/

