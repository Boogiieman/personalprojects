/*function add(num1,num2,callback){
    let err=false
    if (num1==0)
    {
        err=true
    }
    callback(num1+num2,err)
}


function multi(num1,num2,callback){
    callback(num1*num2)
}


function div(num1,num2,callback){
    callback(num1/num2)
}


add(1,20,function(sum,err){
    if(err){
        console.log("First num is Zero")
    }
    else{
    console.log(sum)
    multi(sum,sum,(product)=>{
        console.log(product)
        div(product,10,(result)=>{
            console.log(result)
        })
    })

    }
  
})
*/

const Promise=require('promise')

function add(num1,num2){
    return new Promise((resolve,reject)=>{
        if (num1==0){
            reject("First Number is Zero")
        }
        resolve(num1+num2)
    })
}

add(1,20).then((sum)=>{
    console.log(sum)
}).catch(function(err){
    console.log(err)
})